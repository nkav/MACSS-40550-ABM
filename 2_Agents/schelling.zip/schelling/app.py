import solara
from model import SchellingModel
from mesa.visualization import (  
    SolaraViz,
    make_space_component,
    make_plot_component,
)

## Define agent portrayal: color, shape, and size
def agent_portrayal(agent):
    transparency = agent.desired_share_alike  # Already in range 0-1
    color = "blue" if agent.type == 1 else "red"
    return {
        "color": color,  # Use normalized RGB tuple
        "edgecolors": "black",
        "linewidths": 0.5,
        "marker": "s",
        "size": 40,
        "alpha": transparency,  # Transparency is already in 0-1 range
    }

## Enumerate variable parameters in model: seed, grid dimensions, population density, agent preferences, vision, and relative size of groups.
model_params = {
    "seed": {
        "type": "InputText",
        "value": 42,
        "label": "Random Seed",
    },
    "width": {
        "type": "SliderInt",
        "value": 50,
        "label": "Width",
        "min": 5,
        "max": 100,
        "step": 1,
    },
    "height": {
        "type": "SliderInt",
        "value": 50,
        "label": "Height",
        "min": 5,
        "max": 100,
        "step": 1,
    },
    "density": {
        "type": "SliderFloat",
        "value": 0.7,
        "label": "Population Density",
        "min": 0,
        "max": 1,
        "step": 0.01,
    },
    "min_desired_share_alike": {
        "type": "SliderFloat",
        "value": 0,
        "label": "Min Desired Share Alike",
        "min": 0,
        "max": 1,
        "step": 0.01,
    },
    "max_desired_share_alike": {
        "type": "SliderFloat",
        "value": 1,
        "label": "Max Desired Share Alike",
        "min": 0,
        "max": 1,
        "step": 0.01,
    },
    "group_one_share": {
        "type": "SliderFloat",
        "value": 0.7,
        "label": "Share Type 1 Agents",
        "min": 0,
        "max": 1,
        "step": 0.01,
    },
    "radius": {
        "type": "SliderInt",
        "value": 1,
        "label": "Vision Radius",
        "min": 1,
        "max": 5,
        "step": 1,
    },
    "party_follow_change": {
        "type": "SliderFloat",
        "value": 0.01,
        "label": "Party Follow Change",
        "min": 0,
        "max": 0.1,
        "step": 0.01,
    },
    "depolarization_change": {
        "type": "SliderFloat",
        "value": 0.01,
        "label": "Depolarization Change",
        "min": 0,
        "max": 0.1,
        "step": 0.01,
    },
}

## Instantiate model
schelling_model = SchellingModel()

## Define happiness over time plot
HappyPlot = make_plot_component({"share_happy": "tab:green"})

## Define polarization over time plot
PolarizationPlot = make_plot_component({"avg_polarization": "tab:blue"})

## Define space component
SpaceGraph = make_space_component(agent_portrayal, draw_grid=False)

## Define a component to display current share_happy and avg_polarization
@solara.component
def StatsDisplay(model):
    # Use reactive state to track updates
    share_happy = model.datacollector.get_model_vars_dataframe()["share_happy"].iloc[-1]
    avg_polarization = model.datacollector.get_model_vars_dataframe()["avg_polarization"].iloc[-1]
    return solara.Markdown(f"**Share Happy:** {share_happy:.2f}%\n\n**Avg Polarization:** {avg_polarization:.2f}")

## Instantiate page including all components
page = SolaraViz(
    schelling_model,
    components=[SpaceGraph, HappyPlot, PolarizationPlot, StatsDisplay],
    model_params=model_params,
    name="Schelling Segregation Model",
)
## Return page
page

